export const NavbarData = [
  {
    path:"/",
    title:"Home",
  },
  {
    path:"/pastes",
    title:"Paste",
  },
]